let markdown = require('markdown').markdown;
const publicIp = require('public-ip');
const fs = require('fs');


var content = fs.readFileSync('./data.json', 'utf8');

var data = JSON.parse(content);
console.log(data.name);

data.members = [{
    name:'Cường',
    age:23,
    isBoy:true,
}];

fs.writeFileSync('./data.json',JSON.stringify(data.members));
