var fs = require('fs');

var text = fs.readFileSync('./song.text',{encoding: 'utf8'});
console.log(text);