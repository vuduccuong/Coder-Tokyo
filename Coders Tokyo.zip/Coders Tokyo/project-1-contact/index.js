var fs = require('fs');
var readlineSync = require('readline-sync');

var contacts = [];
var url = './data.json';

//Load Data from data.json
function loadData(){
var fileContent = fs.readFileSync(url);

contacts = JSON.parse(fileContent);
}

//showContact
function showContact(){
    var i=1;
    console.log("*****List contact*****");
    for(let contact of contacts){
        console.log(i + " " + contact.name, contact.phone);
        i++;
    }
    console.log("*********************");
}

//createContact
function creatContact(){
    var name = readlineSync.question("Name: ");
    var phone = parseInt(readlineSync.question("Phone: "));

    let contact = {
        name:name,
        phone:phone,
    };
    contacts.push(contact);

}

//editContact
function editContact(){
    var index = readlineSync.question("Choose contact: ");
    var nameEdit = readlineSync.question("Name: ");
    var phoneEdit = readlineSync.question("Phone: ");

    let contact = {
        name:nameEdit,
        phone:parseInt(phoneEdit),
    }
    contacts[parseInt(index)-1] = contact;
}

//deleteContact
function deleteContact(){
    var index = readlineSync.question("Choose contact: ");

    contacts.splice(parseInt(index)-1,1);
}

//findContact
function findContact(){
    var i=1;
    var keyword = readlineSync.question("Find by name or phone: ");
    console.log(keyword);
    var result = contacts.filter(item=>
        item.name.toUpperCase() === keyword.toUpperCase()
        )
        console.log("*****List contact*****");
    for(let item of result){
        console.log(i + " " +item.name, item.phone);
        ++i;
    }
    console.log("*********************");
}

//saveAndExit
function saveAndExit(){
    var awser = readlineSync.question("Do you want to Exit?(y/n) ");
    if(awser==='y'){
        fs.writeFileSync(url,JSON.stringify(contacts),{encoding:'utf8'});
    }
    else{
        showMenu();
    }
}

//Show menu
function showMenu(){
    console.log("1. Show all contact");
    console.log("2. Creat new contact");
    console.log("3. Edit contact");
    console.log("4. Delete contact");
    console.log("5. Find contact");
    console.log("6. Save & Exit");

    var option = readlineSync.question("> ");
    switch(option){
        case '1':
            showContact();
            showMenu();
            break;
        case '2':
            creatContact();
            console.log("Success!");
            showMenu();
            break;
        case '3':
            editContact();
            console.log("Success!");
            showMenu();
            break;
        case '4':
            deleteContact();
            console.log("Success!");
            showMenu();
            break;
        case '5':
            findContact();
            showMenu();
            break;
        case '6':
            saveAndExit();
            
            break;
        default:
            showMenu();
            break;
    }
}

function Main(){
loadData();
showMenu();
}
Main();
